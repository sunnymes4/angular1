﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ADMIN_Tax : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _CCode = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        Util.BindGridView(gvList, "Select Row_Number() Over (Order By T.AutoID) as SN,T.* From tblTax T");
    }

    private string ValidateData()
    {
        string reqMsg = "";
        if (txtTax.Value.Trim() == "")
        {
            reqMsg = "Please Enter Tax !!";
            msgDiv.Visible = true;
            lblMsg.Text = reqMsg;
            txtTax.Focus();
            return reqMsg;
        }

        if (txtTaxPercent.Value.Trim() == "")
        {
            reqMsg = "Please Enter Tax Percent !!";
            msgDiv.Visible = true;
            lblMsg.Text = reqMsg;
            txtTaxPercent.Focus();
            return reqMsg;
        }

        DataTable dt = new DataTable();
        if (HFID.Value == "0") dt = DBData.getDataTable(DBData.DataPath, "Select * From tblTax Where Tax = '" + txtTax.Value.Trim() + "' and Percentage=" + txtTaxPercent.Value.Trim() + "");
        else dt = DBData.getDataTable(DBData.DataPath, "Select * From tblTax Where Tax = '" + txtTax.Value.Trim() + "' and Percentage=" + txtTaxPercent.Value.Trim() + " and AutoID != " + Convert.ToInt32(HFID.Value) + "");
        if (dt.Rows.Count > 0) reqMsg = "It is Already Exists. Re-Enter It ";
        txtTax.Focus();
        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_Tax";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                sqcmd.Parameters.Add(new SqlParameter("@Tax", SqlDbType.VarChar, 150)).Value = txtTax.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@Percentage", SqlDbType.Float)).Value = txtTaxPercent.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@ApplyForID", SqlDbType.Int)).Value = ddlApplyFor.SelectedValue;
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
               // sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();
                sqcmd.ExecuteNonQuery();
                Response.Redirect("Tax.aspx");
                //Refresh();
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void Refresh()
    {
        btnSave.Text = "Save";
        btnDelete.Enabled = false;
        FillGrid();
        txtTax.Value = ""; txtTaxPercent.Value = "";
        HFID.Value = "0";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Submit();
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Refresh();
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[4].Text).ToString();
        txtTax.Value = gvList.SelectedRow.Cells[2].Text;
        txtTaxPercent.Value = gvList.SelectedRow.Cells[3].Text;
        ddlApplyFor.SelectedValue = gvList.SelectedRow.Cells[5].Text;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }

    private string ValidateForDelete()
    {
        string reqMsg = "";
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "Select * From tblProduct Where AutoID = " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) return reqMsg = "This Tax is already Used So You Cannot Delete This!!";
        else return reqMsg;
        return "";
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        //string msgErr = "";
        //msgErr = ValidateForDelete();
        //if (msgErr.Equals(""))
        //{
        DBData.deleteData(DBData.DataPath, "Delete From tblTax Where AutoID = " + HFID.Value.Trim() + "");
        Response.Redirect("Tax.aspx");
        //}
        //else
        //{
        //    msgDiv.Visible = true;
        //    lblMsg.Text = msgErr;
        //}
    }
}