﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Branch : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "SELECT * From tblBranchDetail Order By BranchName");
        gvList.DataSource = dt;
        gvList.DataBind();
    }

    private string ValidateData()
    {
        string reqMsg = "";
        if (txtBranchName.Value == "")
        {
            reqMsg = "Please Enter Name Of Branch !!";
            msgDiv.Visible = true; lblMsg.Text = reqMsg;
            txtBranchName.Focus();
            return reqMsg;
        }

        DataTable dt = new DataTable();
        if (HFID.Value == "0") dt = DBData.getDataTable(DBData.DataPath, "Select * From tblBranchDetail Where BranchName = '" + txtBranchName.Value.Trim() + "'");
        else dt = DBData.getDataTable(DBData.DataPath, "Select * From tblBranchDetail Where BranchName = '" + txtBranchName.Value.Trim() + "' And AutoID <> " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0)
        {
            reqMsg = "It is Already Exists. Re-Enter It ";
            msgDiv.Visible = true; lblMsg.Text = reqMsg;
            txtBranchName.Focus();
        }
        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_BranchDetail";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                sqcmd.Parameters.Add(new SqlParameter("@BranchName", SqlDbType.VarChar)).Value = txtBranchName.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@Address", SqlDbType.VarChar)).Value = txtBranchAddress.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@MobileNo", SqlDbType.VarChar)).Value = txtMobileNo.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@PhoneNo", SqlDbType.VarChar)).Value = txtPhoneNo.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@ContactPerson", SqlDbType.VarChar)).Value = txtContactPerson.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.ExecuteNonQuery();
                Response.Redirect("Branch.aspx");
                //Refresh();
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void Refresh()
    {
        btnSave.Text = "Save";
        btnDelete.Enabled = false;
        FillGrid();
        txtBranchName.Value = "";
        txtBranchAddress.Value = "";
        txtContactPerson.Value = "";
        txtMobileNo.Value = "";
        txtPhoneNo.Value = "";
        HFID.Value = "0";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("Branch.aspx");
        }
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Refresh();
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[6].Text).ToString();
        txtBranchName.Value = gvList.SelectedRow.Cells[1].Text;
        txtBranchAddress.Value = gvList.SelectedRow.Cells[5].Text;
        txtContactPerson.Value = gvList.SelectedRow.Cells[2].Text;
        txtMobileNo.Value = gvList.SelectedRow.Cells[4].Text;
        txtPhoneNo.Value = gvList.SelectedRow.Cells[3].Text;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }

    private string ValidateForDelete()
    {
        string reqMsg = "";
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "Select * From tblUserDetail Where BranchAutoID = " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) return reqMsg = "This Branch Have Some Users So You Cannot Delete This!!";
        else return reqMsg;
        return "";
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string msgErr = "";
        msgErr = ValidateForDelete();
        if (msgErr.Equals(""))
        {
            DBData.deleteData(DBData.DataPath, "Delete From tblBranchDetail Where AutoID = " + HFID.Value.Trim() + "");
            Response.Redirect("Branch.aspx");
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    protected void btnRefresh_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Branch.aspx");
    }
}
