﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;

public partial class ADMIN_EmpJoining : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _CCode = 0;
    SqlConnection sqcon = null;
    SqlTransaction tran = null;
    SqlCommand sqcmd = null;
    string APfname = string.Empty, PPfname = string.Empty, EmpPhoto = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            Util.BindDropDown(ddlDesignation, "Designation", "AutoID", "Select Designation", DBData.getDataTable(DBData.DataPath, "Select AutoID,Designation From tblDesignation Order By Designation"));
            Util.BindDropDown(ddlState, "State", "AutoID", "Select State", DBData.getDataTable(DBData.DataPath, "Select AutoID,State From tblState Order By AutoID"));
            Util.BindDropDown(ddlBranch, "BranchName", "AutoID", "Select Branch", DBData.getDataTable(DBData.DataPath, "Select AutoID,BranchName From tblBranchDetail Where IsAlive='True'"));
            Util.BindDropDown(ddlDistrict, "District", "AutoID", "Select District", DBData.getDataTable(DBData.DataPath, "Select AutoID,District From tblDistrict Order By AutoID"));
            txtEntryDate.SelectedDate = Convert.ToDateTime(System.DateTime.Now.ToString("dd/MM/yyyy"));
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
        //DivRegDetails.Visible = false;
    }

    private string ValidateSearching()
    {
        string msgErr = "";
        if (txtRegistrationNo.Value.Trim() == "")
        {
            msgErr = "Please Valid Registration-No  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtRegistrationNo.Focus();
            return msgErr;
        }
        return msgErr;
    }

    protected void btnVerify_Click(object sender, EventArgs e)
    {
        string reqMsg = ValidateSearching();
        if (reqMsg.Equals(""))
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "Select * from tblUserRegistration where ApplicationID='" + txtRegistrationNo.Value.ToString() + "' and IsPaid='True' And AutoID Not In (Select RegAutoID From tblEmployeeJoining)");
            if (dt.Rows.Count > 0)
            {
                DivHeader.Visible = false; DivRegDetails.Visible = true;
                msgDiv.Visible = false; lblMsg.Text = "";
                //================================================
                ViewState["RegAutoID"] = dt.Rows[0]["AutoID"].ToString();
                txtName.Value = dt.Rows[0]["FirstName"].ToString() + " " + dt.Rows[0]["LastName"].ToString();
                txtCAddress.Value = dt.Rows[0]["TAddress"].ToString();
                txtEmailID.Value = dt.Rows[0]["EmailID"].ToString();
                txtMobileNo.Value = dt.Rows[0]["MobileNo"].ToString();
                txtPAddress.Value = dt.Rows[0]["PAddress"].ToString();
                txtPinNo.Value = dt.Rows[0]["PinCode"].ToString();
                txtEmployeeID.Value = dt.Rows[0]["ApplicationID"].ToString();
                ddlState.SelectedValue = dt.Rows[0]["StateAutoID"].ToString();
                ddlDistrict.SelectedValue = dt.Rows[0]["DistrictAutoID"].ToString();
                //================================================
            }
            else
            {
                txtName.Value = "";
                txtCAddress.Value = "";
                txtEmailID.Value = "";
                txtMobileNo.Value = "";
                txtPAddress.Value = "";
                txtPinNo.Value = "";
                txtEmployeeID.Value = "";
                ddlState.SelectedValue = "";
                ddlDistrict.SelectedValue = "";
                lblMsg.Text = "Registration-No Either Wrong Or Payment Not Done Or Already Joined. Please Re-Enter Valid Registration-No ...";
                msgDiv.Visible = true;
                txtRegistrationNo.Focus();
                return;
            }
        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlState.SelectedIndex > 0)
        {
            Util.BindDropDown(ddlDistrict, "District", "AutoID", "Select District", DBData.getDataTable(DBData.DataPath, "Select AutoID,District From tblDistrict Where StateID = " + ddlState.SelectedValue + " Order By AutoID"));
        }
    }

    private string ValidateData()
    {
        string msgErr = "";
        if (ViewState["RegAutoID"] == null)
        {
            msgErr = "Please Verify Registration Number !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtRegistrationNo.Focus();
            return msgErr;
        }

        if (txtDOB.SelectedDate.ToString() == "")
        {
            msgErr = "Enter Date Of Birth  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtDOB.Focus();
            return msgErr;
        }

        if (ddlBranch.SelectedIndex <= 0)
        {
            msgErr = "Please Branch Name ..";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlBranch.Focus();
            return msgErr;
        }

        if (ddlDesignation.SelectedIndex <= 0)
        {
            msgErr = "Please Select Designation ..";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlDesignation.Focus();
            return msgErr;
        }

        if (txtName.Value.Trim() == "")
        {
            msgErr = "Please Enter Name ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtName.Focus();
            return msgErr;
        }

        if (txtFatherName.Value.Trim() == "")
        {
            msgErr = "Please Enter Father Name ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtFatherName.Focus();
            return msgErr;
        }

        if (txtMotherName.Value.Trim() == "")
        {
            msgErr = "Please Enter Mother Name ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtMotherName.Focus();
            return msgErr;
        }

        if (txtPAddress.Value.Trim() == "")
        {
            msgErr = "Please Enter Permanent Address  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtPAddress.Focus();
            return msgErr;
        }

        if (ddlState.SelectedIndex <= 0)
        {
            msgErr = "Please Select State ..";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlState.Focus();
            return msgErr;
        }

        if (ddlDistrict.SelectedIndex <= 0)
        {
            msgErr = "Please Select District ..";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlDistrict.Focus();
            return msgErr;
        }

        if (txtMobileNo.Value.Trim() == "")
        {
            msgErr = "Please Enter MobileNo  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtMobileNo.Focus();
            return msgErr;
        }

        if (txtEmailID.Value.Trim() == "")
        {
            msgErr = "Please Enter Valid Email-ID  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtEmailID.Focus();
            return msgErr;
        }

        if (FUPhotoProof.HasFile == true)
        {
            if (CheckFileType(FUPhotoProof.PostedFile.FileName)== false)
            {
                msgErr = "Photo Proof Document's Must Be In .doc or .docx Format !!";
                msgDiv.Visible = true;
                lblMsg.Text = msgErr;
                FUPhotoProof.Focus();
                return msgErr;
            }
        }

        if (FUAddressProof.HasFile == true)
        {
            if (CheckFileType(FUAddressProof.PostedFile.FileName)== false)
            {
                msgErr = "Address Proof Document's Must Be In .doc or .docx Format !!";
                msgDiv.Visible = true;
                lblMsg.Text = msgErr;
                FUAddressProof.Focus();
                return msgErr;
            }
        }

        if (FUPhoto.HasFile == true)
        {
            if (CheckPhotoFileType(FUPhoto.PostedFile.FileName) == false)
            {
                msgErr = "Photo Must Be In .JPEG or .JPG or .PNG or .GIF Format !!";
                msgDiv.Visible = true;
                lblMsg.Text = msgErr;
                FUPhoto.Focus();
                return msgErr;
            }
        }
        return msgErr;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            string msgErr = ValidateData();
            if (msgErr.Equals(""))
            {
                sqcon = new SqlConnection(DBData.DataPath);
                if (sqcon.State == ConnectionState.Closed) sqcon.Open();
                tran = sqcon.BeginTransaction(System.Data.IsolationLevel.Serializable);
                UploadDocument();
                UploadImage();
                SaveData();
                tran.Commit();
                txtName.Value = "";
                //txtDOB.SelectedDate = "";
                txtEmailID.Value = "";
                txtMobileNo.Value = "";
                txtMobileNo.Value = "";
                txtQualification.Value = "";
                txtCAddress.Value = "";
                txtPAddress.Value = "";
                ddlState.SelectedIndex = 0;
                ddlDistrict.SelectedIndex = 0;
                txtExperiance.Value = "";
                lblMsg.ForeColor = System.Drawing.Color.Green;
                msgDiv.Visible = true;
                lblMsg.Text = "Thankyou For Employee Joining.";
                //SMSSENDING sms = new SMSSENDING(ViewState["MobNo"].ToString(), "Mecson", "Dear " + ViewState["Name"].ToString() + ", Thankyou For Registration. Your User Name : " + ViewState["appID"].ToString() + " And Password : " + ViewState["PWD"].ToString() + "");
            }
        }
        catch (Exception ex)
        {
            tran.Rollback();
            msgDiv.Visible = true;
            lblMsg.Text = ex.Message;
        }
    }

    private void UploadDocument()
    {
        if (FUPhotoProof.HasFile || FUAddressProof.HasFile)
        {
            if (CheckFileType(FUAddressProof.PostedFile.FileName))
            {
                HttpPostedFile APfile = FUAddressProof.PostedFile;
                if (APfile != null && APfile.ContentLength > 0)
                {
                    string strPath = Server.MapPath(".");
                    //CreateDirectory(strPath + "\\ADMIN\\AProof");
                    DataTable dt = new DataTable();
                    dt = DBData.SqlDataAdapter(sqcon, "[UniqueID] 1", tran);
                    APfname = dt.Rows[0][0].ToString() + "_" + Path.GetExtension(APfile.FileName);
                    //APfile.SaveAs(Server.MapPath(Path.Combine("~/ADMIN/AProof/", "AP" + APfname)));

                    //=====For Ftp Password Function ================
                    byte[] data = FUAddressProof.FileBytes;
                    using (WebClient client = new WebClient())
                    {
                        client.UploadData("ftp://" + "godfatherintern" + ":" + "B%rb1n16" + "@" + "godfatherinternationaltrust.in/httpdocs/ADMIN/AProof/" + APfname + "", data);
                    }
                    //=========== For End Function ================
                }
            }
            if (CheckFileType(FUPhotoProof.PostedFile.FileName))
            {
                HttpPostedFile PPfile = FUPhotoProof.PostedFile;
                if (PPfile != null && PPfile.ContentLength > 0)
                {
                    string strPath = Server.MapPath(".");
                    //CreateDirectory(strPath + "\\ADMIN\\PProof");
                    DataTable dt = new DataTable();
                    dt = DBData.SqlDataAdapter(sqcon, "[UniqueID] 1", tran);
                    PPfname = dt.Rows[0][0].ToString() + "_" + Path.GetExtension(PPfile.FileName);
                    //PPfile.SaveAs(Server.MapPath(Path.Combine("~/ADMIN/PProof/", "AP" + PPfname)));
                    //=====For Ftp Password Function ================
                    byte[] data = FUPhotoProof.FileBytes;
                    using (WebClient client = new WebClient())
                    {
                        client.UploadData("ftp://" + "godfatherintern" + ":" + "B%rb1n16" + "@" + "godfatherinternationaltrust.in/httpdocs/ADMIN/PProof/" + PPfname + "", data);
                    }
                    //=========== For End Function ================
                }
            }
            else
            {
                msgDiv.Visible = true;
                lblMsg.Text = "Document's Must Be In .doc or .docx Format !!";
            }
        }
    }

    private void UploadImage()
    {
        if (FUPhoto.HasFile)
        {
            if (CheckPhotoFileType(FUPhoto.PostedFile.FileName))
            {
                HttpPostedFile Photofile = FUPhoto.PostedFile;
                if (Photofile != null && Photofile.ContentLength > 0)
                {
                    string strPath = Server.MapPath(".");
                    //CreateDirectory(strPath + "\\ADMIN\\EmpImage");
                    DataTable dt = new DataTable();
                    dt = DBData.SqlDataAdapter(sqcon, "[UniqueID] 1", tran);
                    EmpPhoto = dt.Rows[0][0].ToString() + "_" + Path.GetExtension(Photofile.FileName);
                    //Photofile.SaveAs(Server.MapPath(Path.Combine("~/ADMIN/AProof/", "EIMG" + EmpPhoto)));

                    //=====For Ftp Password Function ================
                    byte[] data = FUPhoto.FileBytes;
                    using (WebClient client = new WebClient())
                    {
                        client.UploadData("ftp://" + "godfatherintern" + ":" + "B%rb1n16" + "@" + "godfatherinternationaltrust.in/httpdocs/ADMIN/EmpImage/" + EmpPhoto + "", data);
                    }
                    //=========== For End Function ================
                }
            }
            else
            {
                msgDiv.Visible = true;
                lblMsg.Text = "Photo Must Be In .JPEG or .JPG or .PNG or .GIF Format !!";
            }
        }
    }

    private void SaveData()
    {
        sqcmd = new SqlCommand("SP_IU_EmployeeJoining", sqcon);
        sqcmd.CommandType = CommandType.StoredProcedure;
        sqcmd.Transaction = tran;
        sqcmd.Parameters.AddWithValue("@AutoID", 0);
        sqcmd.Parameters.AddWithValue("@RegAutoID", ViewState["RegAutoID"].ToString());
        sqcmd.Parameters.AddWithValue("@BranchAutoID", Convert.ToInt32(ddlBranch.SelectedValue));
        sqcmd.Parameters.AddWithValue("@EmployeeID", txtEmployeeID.Value.Trim());
        sqcmd.Parameters.AddWithValue("@DesignationID", Convert.ToInt32(ddlDesignation.SelectedValue));
        sqcmd.Parameters.AddWithValue("@EntryDate", txtEntryDate.SelectedDate.ToString());
        sqcmd.Parameters.AddWithValue("@Name", txtName.Value.Trim());
        sqcmd.Parameters.AddWithValue("@FatherName", txtFatherName.Value.Trim());
        sqcmd.Parameters.AddWithValue("@MotherName", txtMotherName.Value.Trim());
        sqcmd.Parameters.AddWithValue("@LAddress", txtCAddress.Value.Trim());
        sqcmd.Parameters.AddWithValue("@PAddress", txtPAddress.Value.Trim());
        sqcmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Value.Trim());
        sqcmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Value.Trim());
        sqcmd.Parameters.AddWithValue("@EmailID", txtEmailID.Value.Trim());
        sqcmd.Parameters.AddWithValue("@DOB", txtDOB.SelectedDate.ToString());
        if (ddlDistrict.SelectedIndex > 0) sqcmd.Parameters.AddWithValue("@DistrictID", Convert.ToInt32(ddlDistrict.SelectedValue));
        sqcmd.Parameters.AddWithValue("@Photo", EmpPhoto.ToString());
        sqcmd.Parameters.AddWithValue("@PhotoProof", PPfname.ToString());
        sqcmd.Parameters.AddWithValue("@AddressProof", APfname.Trim());
        sqcmd.Parameters.AddWithValue("@Qualification", txtQualification.Value.Trim());
        sqcmd.Parameters.AddWithValue("@Expirence", txtExperiance.Value.Trim());
        sqcmd.Parameters.AddWithValue("@Status", "True");
        sqcmd.Parameters.AddWithValue("@CreatedBy", Page.User.Identity.Name);
        sqcmd.Parameters.AddWithValue("@CreatedIP", Request.UserHostAddress.ToString());
        sqcmd.ExecuteNonQuery();
    }

    public bool CheckFileType(string FileName)
    {
        string Ext = Path.GetExtension(FileName);
        switch (Ext.ToUpper())
        {
            case ".DOC":
                return true;
                break;
            case ".DOCX":
                return true;
                break;
            default:
                return false;
                break;
        }
    }

    public bool CheckPhotoFileType(string FileName)
    {
        string Ext = Path.GetExtension(FileName);
        switch (Ext.ToUpper())
        {
            case ".JPG":
                return true;
                break;
            case ".JPEG":
                return true;
                break;
            case ".PNG":
                return true;
                break;
            case ".GIF":
                return true;
                break;
            default:
                return false;
                break;
        }
    }

    private void CreateDirectory(string path)
    {
        if (!System.IO.Directory.Exists(path))
        {
            System.IO.Directory.CreateDirectory(path);
        }
    }
}
