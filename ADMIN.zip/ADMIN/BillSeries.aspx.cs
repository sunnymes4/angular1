﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class BillSeries : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "SELECT AutoID,ApplyForID,(Case When ApplyForID = 1 Then 'Purchase Order' When ApplyForID = 2 Then 'Purchase' When ApplyForID = 3 Then 'Debit Note' When ApplyForID = 4 Then 'Sale Order' When ApplyForID = 5 Then 'Sale' When ApplyForID = 6 Then 'Credit Note' End) As ApplyFor,SeriesName,MaxSlNo From tblBillSeries Order By ApplyForID");
        gvList.DataSource = dt;
        gvList.DataBind();
    }

    private string ValidateData()
    {
        string reqMsg = "";
        if (ddlApplyFor.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Apply For !!";
            ddlApplyFor.Focus();
            return reqMsg;
        }

        DataTable dt = new DataTable();
        if (HFID.Value == "0") dt = DBData.getDataTable(DBData.DataPath, "Select * From tblBillSeries Where ApplyForID = " + ddlApplyFor.SelectedIndex + "");
        else dt = DBData.getDataTable(DBData.DataPath, "Select * From tblBillSeries Where ApplyForID = " + ddlApplyFor.SelectedIndex + " And ApplyForID <> " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) reqMsg = "Series Are Also Created For " + ddlApplyFor.SelectedItem.Text.Trim() + "";
        ddlApplyFor.Focus();
        return reqMsg;

        if (txtSeriesName.Value.Trim() == "")
        {
            reqMsg = "Please Enter Series Name !!";
            txtSeriesName.Focus();
            return reqMsg;
        }

        if (txtMaxSlNo.Value.Trim() == "")
        {
            reqMsg = "Please Enter Max Sl. No. !!";
            txtMaxSlNo.Focus();
            return reqMsg;
        }

        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_BillSeries";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                sqcmd.Parameters.Add(new SqlParameter("@ApplyForID", SqlDbType.Int)).Value = ddlApplyFor.SelectedIndex;
                sqcmd.Parameters.Add(new SqlParameter("@SeriesName", SqlDbType.VarChar)).Value = txtSeriesName.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@MaxSlNo", SqlDbType.Int)).Value = txtMaxSlNo.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.ExecuteNonQuery();
                Response.Redirect("BillSeries.aspx");
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void Refresh()
    {
        btnSave.Text = "Save";
        btnDelete.Enabled = false;
        FillGrid();
        ddlApplyFor.SelectedIndex = 0;
        txtSeriesName.Value = "";
        txtMaxSlNo.Value = "";
        HFID.Value = "0";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("BillSeries.aspx");
        }
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("BillSeries.aspx");
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        //DataTable dt = new DataTable();
        //dt = DBData.getDataTable(DBData.DataPath, "Select * From tblBillSeries Where ApplyForID = " + ddlApplyFor.SelectedIndex + " And ApplyForID <> " + HFID.Value.Trim() + "");
        //if (dt.Rows.Count > 0) reqMsg = "Series Are Also Created For " + ddlApplyFor.SelectedItem.Text.Trim() + "";
        //ddlApplyFor.Focus();
        //return reqMsg;
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[5].Text).ToString();
        ddlApplyFor.SelectedIndex = Convert.ToInt32(gvList.SelectedRow.Cells[1].Text);
        txtSeriesName.Value = gvList.SelectedRow.Cells[3].Text;
        txtMaxSlNo.Value = gvList.SelectedRow.Cells[4].Text;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }
   
    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }
}
