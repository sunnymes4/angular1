﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Product : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            Util.BindDropDown(ddlCategory, "CategoryName", "AutoID", "Select Category", DBData.getDataTable(DBData.DataPath, "Select AutoID,CategoryName from tblCategory"));
            Util.BindDropDown(ddlTax, "Tax", "AutoID", "Select Purchase Tax", DBData.getDataTable(DBData.DataPath, "Select AutoID,Tax from tblTax where IsAlive='True' And ApplyForID = 0"));
            Util.BindDropDown(ddlSaleTax, "Tax", "AutoID", "Select Sale Tax", DBData.getDataTable(DBData.DataPath, "Select AutoID,Tax from tblTax where IsAlive='True' And ApplyForID = 1"));
            Util.BindDropDown(ddlUnit, "Unit", "AutoID", "Select Unit", DBData.getDataTable(DBData.DataPath, "Select AutoID, Unit from tblUnit"));
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        msgDiv.Visible = false;
        lblMsg.Text = "";
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "SELECT tblProduct.AutoID, tblProduct.ProductName, tblProduct.CategoryAutoID, (Select CategoryName From tblCategory Where AutoID = tblProduct.CategoryAutoID) As CategoryName, tblProduct.UnitAutoID, (Select Unit From tblUnit Where AutoID = tblProduct.UnitAutoID) As Unit, tblProduct.Packing, tblProduct.TaxAutoID, (Select Tax From tblTax Where AutoID = tblProduct.TaxAutoID) As Tax, tblProduct.saleTaxAutoID ,(Select Tax From tblTax Where AutoID = tblProduct.saleTaxAutoID) As SaleTax FROM tblProduct Order By ProductName");
        gvList.DataSource = dt;
        gvList.DataBind();
    }

    private string ValidateData()
    {
        string reqMsg = "";
        if (txtProductName.Value.Trim() == "")
        {
            reqMsg = "Please Enter Name Of Product !!";
            txtProductName.Focus();
            return reqMsg;
        }

        if (Convert.ToInt32(HFID.Value) == 0)
        {
            string ctr = DBData.GetScalarString(DBData.DataPath, "Select IsNull(Count(*),0) from tblProduct Where ProductName = '" + txtProductName.Value.Trim() + "'");
            if (ctr != "0")
            {
                reqMsg = "Duplicate Product Cannot Be Enter !!";
                txtProductName.Focus();
                return reqMsg;
            }
        }

        if (Convert.ToInt32(HFID.Value) > 0)
        {
            string ctr = DBData.GetScalarString(DBData.DataPath, "Select IsNull(Count(*),0) from tblProduct Where ProductName = '" + txtProductName.Value.Trim() + "' And AutoID <> " + Convert.ToInt32(HFID.Value) + "");
            if (ctr != "0")
            {
                reqMsg = "Duplicate Product Cannot Be Enter !!";
                txtProductName.Focus();
                return reqMsg;
            }
        }

        if (ddlCategory.SelectedIndex <=0)
        {
            reqMsg = "Please Select Category !!";
            ddlCategory.Focus();
            return reqMsg;
        }

        if (ddlTax.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Tax !!";
            ddlTax.Focus();
            return reqMsg;
        }

        if (ddlUnit.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Unit !!";
            ddlUnit.Focus();
            return reqMsg;
        }

        if (txtPacking.Value.Trim() == "")
        {
            reqMsg = "Please Enter Packing !!";
            txtPacking.Focus();
            return reqMsg;
        }

        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_Product";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                sqcmd.Parameters.Add(new SqlParameter("@ProductName", SqlDbType.VarChar, 5000)).Value = txtProductName.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@CategoryAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlCategory.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@TaxAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlTax.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@SaleTaxAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlSaleTax.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@UnitAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlUnit.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@Packing", SqlDbType.Int)).Value = Convert.ToInt32(txtPacking.Value.Trim());
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();
                sqcmd.ExecuteNonQuery();
                Response.Redirect("Product.aspx");
                //Refresh();
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        Submit();
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        ddlTax.SelectedValue = gvList.SelectedRow.Cells[8].Text;
        ddlSaleTax.SelectedValue = gvList.SelectedRow.Cells[10].Text;
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[7].Text).ToString();
        txtProductName.Value = gvList.SelectedRow.Cells[1].Text;
        ddlCategory.SelectedValue = gvList.SelectedRow.Cells[2].Text;
        ddlUnit.SelectedValue = gvList.SelectedRow.Cells[4].Text;
        txtPacking.Value = gvList.SelectedRow.Cells[6].Text;
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "Select * from tblCode Where ProductAutoID = " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) txtPacking.Disabled = true;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }

    private string ValidateForDelete()
    {
        string msgErr = "";
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "Select * from tblCode Where ProductAutoID = " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) msgErr = "This Product Have Some Code So You Cannot Delete This !!";
        return msgErr;
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string reqErr = ValidateForDelete();
        if (reqErr.Equals(""))
        {
            DBData.deleteData(DBData.DataPath, "Delete From tblProduct Where AutoID = " + HFID.Value.Trim() + "");
            Response.Redirect("Product.aspx");
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = reqErr;
        }
    }

    private void Refresh()
    {
        btnSave.Text = "Save";
        btnDelete.Enabled = false;
        FillGrid();
        ddlCategory.SelectedIndex = 0;
        ddlUnit.SelectedIndex = 0;
        ddlTax.SelectedIndex = 0;
        txtProductName.Value = "";
        txtPacking.Value = "";
        HFID.Value = "0";
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Refresh();
    }
}
