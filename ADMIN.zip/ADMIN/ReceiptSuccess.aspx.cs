﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ADMIN_ReceiptSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            lblRefNo.Text = "Your Receipt Has Been Successfully Generated. Your Receipt No Is : " + Convert.ToString(Request.QueryString["RF"].ToString());
            DataTable dt = new DataTable();
            msgDiv.Visible = false;
            btnPrint.Enabled = true;
            //dt = DBData.getDataTable(DBData.DataPath, "[dbo].[SP_S_UserRegistration] " + CID + "");
            //if (dt.Rows.Count > 0)
            //{
            //    DOSMS(dt.Rows[0]["MobileNo"].ToString(), dt.Rows[0]["Name"].ToString(), dt.Rows[0]["ApplicationID"].ToString());
            //    msgDiv.Visible = true;
            //    LblMsg.Text = "Your Registration Has Been Completed. Your Registration No :- " + dt.Rows[0]["ApplicationID"].ToString() + "";
            //    LblMsg.ForeColor = System.Drawing.Color.Green;
            //    DetailsView1.DataSource = null;
            //    DetailsView1.DataSource = dt;
            //    DetailsView1.DataBind();
            //    btnPrint.Enabled = true;
            //    btnDonate.Enabled = true;
            //}
        }
    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        //string script = " <script type=\"text/javascript\">  window.open('ReceiptPrint.aspx?RF=" + Request.QueryString["RF"].ToString() + "');   </script> ";
        //ScriptManager.RegisterStartupScript(this, typeof(Page), "alert", script, false);
        Response.Redirect("ReceiptPrint.aspx?RF=" + Convert.ToString(Request.QueryString["RF"].ToString()) + "", false);
    }

    //private void DOSMS(string MobNo, string Name, string appID)
    //{
    //    try
    //    {
    //        SMSSENDING sms = new SMSSENDING(MobNo, "GODFIT", "Dear " + Name + ", Thankyou For Registration. Your Registration Number : " + appID + "");
    //    }
    //    catch (Exception ex)
    //    {

    //    }
    //}

    //protected void btnDonate_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("https://www.payumoney.com/paybypayumoney/#/78885", false);
    //}
}
