﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class District : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _CCode = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            Util.BindDropDown(ddlState, "State", "AutoID", "Select State", DBData.getDataTable(DBData.DataPath, "Select AutoID,State From tblState Order By AutoID"));
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        Util.BindGridView(gvList, "Select Row_Number() Over (Order By D.District) as SN,D.* From tblDistrict D Order By District");
    }

    private void FillGridFiltered()
    {
        if (ddlState.SelectedIndex > 0)
        {
            Util.BindGridView(gvList, "Select Row_Number() Over (Order By D.District) as SN,D.* From tblDistrict D where D.StateID=" + Convert.ToInt32(ddlState.SelectedValue) + " Order By D.District");
        }
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlState.SelectedValue = Convert.ToInt32(gvList.SelectedRow.Cells[2].Text).ToString();
            txtDistrict.Value = gvList.SelectedRow.Cells[3].Text;
            HFAutoID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[4].Text).ToString();
            btnDelete.Enabled = true;
            btnSave.Text = "Update";
        }
        catch (Exception ex) { }
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        if (ddlState.SelectedIndex > 0) FillGridFiltered();
        else FillGrid();
    }

    private string ValidateData()
    {
        string msgErr = "";
        if (ddlState.SelectedIndex <= 0)
        {
            msgErr = "Please Select State Name ..";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlState.Focus();
            return msgErr;
        }

        if (txtDistrict.Value.Trim() == "")
        {
            msgErr = "Please Enter District Name  ...";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtDistrict.Focus();
            return msgErr;
        }

        DataTable dt = new DataTable();
        if (HFAutoID.Value == "0") dt = DBData.getDataTable(DBData.DataPath, "Select * From tblDistrict Where District = '" + txtDistrict.Value.Trim() + "'");
        else dt = DBData.getDataTable(DBData.DataPath, "Select * From tblDistrict Where District = '" + txtDistrict.Value.Trim() + "' And AutoID <> " + HFAutoID.Value.Trim() + "");
        if (dt.Rows.Count > 0)
        {
            msgErr = "It is Already Exists. Re-Enter It ";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
        txtDistrict.Focus();
        return msgErr;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("District.aspx");
        }
    }

    private void Submit()
    {
        string reqMsg = ValidateData();
        if (reqMsg.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_District";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int));
                sqcmd.Parameters["@AutoID"].Value = Convert.ToInt32(HFAutoID.Value);

                sqcmd.Parameters.Add(new SqlParameter("@StateID", SqlDbType.Int));
                sqcmd.Parameters["@StateID"].Value = Convert.ToInt32(ddlState.SelectedValue);

                sqcmd.Parameters.Add(new SqlParameter("@District", SqlDbType.VarChar, 100));
                sqcmd.Parameters["@District"].Value = txtDistrict.Value.Trim();

                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();

                sqcmd.ExecuteNonQuery();
                Response.Redirect("District.aspx");
            }
            catch (Exception ex)
            {
                Scriptmassage(ex.Message);
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            Scriptmassage(reqMsg);
            msgDiv.Visible = true;
            lblMsg.Text = reqMsg;
        }
    }

    private void Scriptmassage(string strmsg)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + strmsg + "');", true);
    }

    private void RefResh()
    {
        ddlState.SelectedIndex = 0; txtDistrict.Value = ""; txtDistrict.Value = ""; HFAutoID.Value = "0";
        btnSave.Text = "Save"; btnDelete.Enabled = false;
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("District.aspx");
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (HFAutoID.Value != "0")
        {
            DBData.deleteData(DBData.DataPath, "delete from tblDistrict where AutoID=" + Convert.ToInt32(HFAutoID.Value.Trim()) + "");
            Response.Redirect("District.aspx");
        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillGridFiltered();
    }
}
