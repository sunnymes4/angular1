﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class MasterPage : System.Web.UI.MasterPage
{
    UtilityCls Util = new UtilityCls();
    DataTable dt = new DataTable();
    SqlConnection sqcon = new SqlConnection(DBData.DataPath);
    public string UName = "";

    protected void Page_Init(object sender, EventArgs e)
    {
        //Remove History
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["LoginAutoID"] == null || Convert.ToString(Session["LoginAutoID"]) == "")
        //{
        //    Response.Redirect("Login.html");
        //}
        //else
        //{
        UName = "Welcome - " + Page.User.Identity.Name.ToString();
        lst.Text = CreateMenu();
        //}
    }

    private string CreateMenu()
    {
        try
        {
            UName = Page.User.Identity.Name.ToString();
            //string RoleID = Session["RoleAutoID"].ToString();
            string Table = "";
            DataTable dt1 = new DataTable();
            //dt1 = DBData.getDataTable(DBData.DataPath, "Select AutoID,MenuName From tblMenu Where IsAlive='True' And Under=0 And AutoID Not In (Select MenuAutoID From tblPriviledge Where RoleAutoID=" + Session["RoleAutoID"].ToString() + ")");
            dt1 = DBData.getDataTable(DBData.DataPath, "Select AutoID,MenuName From tblMenu Where IsAlive='True' And Under=0 And AutoID Not In (Select MenuAutoID From tblPriviledge Where RoleAutoID=(Select RoleAutoID from tblUserDetail Where UserName = '" + Page.User.Identity.Name.ToString().Trim() + "'))");
            foreach (DataRow dr1 in dt1.Rows)
            {
                DataTable dt = new DataTable();
                dt = DBData.getDataTable(DBData.DataPath, "Select MenuName,LinkName From tblMenu Where IsAlive='True' And Under=" + dr1["AutoID"].ToString() + " And AutoID Not In (Select MenuAutoID From tblPriviledge Where RoleAutoID=(Select RoleAutoID from tblUserDetail Where UserName = '" + Page.User.Identity.Name.ToString().Trim() + "'))");
                Table += "<li class=\"dropdown\">";
                Table += "<a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">" + dr1["MenuName"].ToString() + " <span class=\"caret\"></span></a>";
                Table += "<ul class=\"dropdown-menu\">";
                foreach (DataRow dr in dt.Rows)
                {
                    Table += "<li><a href=\"" + dr["LinkName"].ToString() + "\">" + dr["MenuName"].ToString() + "</a></li>";
                }
                Table += "</ul>";
                Table += "</li>";
            }
            return Table;
        }
        catch (Exception ex)
        { }
        return "";
    }

    protected void lblLogout_Click(object sender, EventArgs e)
    {
        Session["LoginAutoID"] = null;
        Session.Abandon();
        Session.Clear();
        Session["LoginAutoID"] = "";
        //HttpCookie h = (HttpCookie)Request.Cookies["IsAlive"];
        //Response.Cookies.Remove("IsAlive");
        FormsAuthentication.SignOut();
        Response.Redirect("~/Login.html");
    }
}
