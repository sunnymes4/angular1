﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ChangePassword : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    SqlConnection sqcon = new SqlConnection(DBData.DataPath);
    int AutoIDVar = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!(Page.IsPostBack))
        {
            txtNewPassword.Value = "";
            txtConfirmPassword.Value = "";
            msgDiv.Visible = false;
        }
    }

    private void Scriptmassage(string strmsg)
    {
        Response.Write("<script Language='javascript'>alert('" + strmsg + "')</script>");
    }

    private string Validatedata()
    {
        string strmsg = string.Empty;

        if (txtNewPassword.Value == "")
        {
            //Scriptmassage("Please Enter New Password");
            strmsg = "Please Enter New Password";
            this.txtNewPassword.Focus();
            return strmsg;
        }
        if (txtConfirmPassword.Value == "")
        {
            //Scriptmassage("Please Enter Confirm Password");
            strmsg = "Please Enter Confirm Password";
            this.txtConfirmPassword.Focus();
            return strmsg;
        }
        if (txtNewPassword.Value != txtConfirmPassword.Value)
        {
            //Scriptmassage("New Password And Confirm Password Must Be Same");
            strmsg = "New Password And Confirm Password Must Be Same";
            txtNewPassword.Focus();
            return strmsg;
        }
        return strmsg;
    }

    protected void button_Click(object sender, EventArgs e)
    {
        string MsgReg = "";
        MsgReg = Validatedata();
        if (MsgReg.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_U_ChangePassword";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int));
                sqcmd.Parameters["@AutoID"].Value = DBData.GetScalarString(DBData.DataPath, "Select AutoID From tblUserDetail Where UserName = '" + Page.User.Identity.Name + "'");
                sqcmd.Parameters.Add("@ChangePwd", SqlDbType.VarChar, 50).Value = new Encryptor("x7hkVXoObeI=").Encrypt(txtConfirmPassword.Value.Trim()).ToString();
                sqcmd.Parameters.Add("@ConfirmPassword", SqlDbType.VarChar, 50).Value = new Encryptor("x7hkVXoObeI=").Encrypt(txtConfirmPassword.Value.Trim()).ToString();
                sqcmd.ExecuteNonQuery();
                msgDiv.Visible = true;
                lblMsg.Text = "Your Password Successfully Changed";

            }
            catch (Exception ex)
            {
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = MsgReg;
        }
    }
}
