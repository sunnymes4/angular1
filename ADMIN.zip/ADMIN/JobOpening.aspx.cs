﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ADMIN_JobOpening : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _CCode = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            Util.BindDropDown(ddlDesignation, "Designation", "AutoID", "Select Designation", DBData.getDataTable(DBData.DataPath, "Select AutoID,Designation From tblDesignation Order By Designation"));
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        Util.BindGridView(gvList, "Select Row_Number() Over (Order By JO.AutoID) as SN,JO.*,D.Designation,Convert(varchar(10),JO.opFDate,103) as FDate,Convert(varchar(10),JO.opLDate,103) as LDate From tblJobOpening JO Left Outer Join tblDesignation D on D.AutoID=JO.DesignationID");
    }

    private void FillGridFiltered()
    {
        if (ddlDesignation.SelectedIndex > 0)
        {
            Util.BindGridView(gvList, "Select Row_Number() Over (Order By JO.AutoID) as SN,JO.*,D.Designation,Convert(varchar(10),JO.opFDate,103) as FDate,Convert(varchar(10),JO.opLDate,103) as LDate From tblJobOpening JO Left Outer Join tblDesignation D on D.AutoID=JO.DesignationID Where JO.DesignationID=" + Convert.ToInt32(ddlDesignation.SelectedValue) + "");
        }
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlDesignation.SelectedValue = Convert.ToInt32(gvList.SelectedRow.Cells[2].Text).ToString();
            txtNoOfVacancy.Value = gvList.SelectedRow.Cells[4].Text;
            txtRequiredQualification.Value = gvList.SelectedRow.Cells[5].Text;
            txtExperiance.Value = gvList.SelectedRow.Cells[6].Text;
            txtOpFDate.SelectedDate = Convert.ToDateTime(gvList.SelectedRow.Cells[7].Text);
            txtOpLDate.SelectedDate = Convert.ToDateTime(gvList.SelectedRow.Cells[8].Text);
            HFAutoID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[9].Text).ToString();
            btnDelete.Enabled = true;
            btnSave.Text = "Update";
        }
        catch (Exception ex) { }
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        if (ddlDesignation.SelectedIndex > 0) FillGridFiltered();
        else FillGrid();
    }

    private string ValidateData()
    {
        string msgErr = "";
        if (ddlDesignation.SelectedIndex <= 0)
        {
            msgErr = "Please Select Designation !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlDesignation.Focus();
            return msgErr;
        }

        if (txtNoOfVacancy.Value.Trim() == "")
        {
            msgErr = "Please Enter No. Of Vacancy !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtNoOfVacancy.Focus();
            return msgErr;
        }

        if (txtRequiredQualification.Value.Trim() == "")
        {
            msgErr = "Please Enter Required Qualification !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtRequiredQualification.Focus();
            return msgErr;
        }

        if (txtOpFDate.SelectedDate.ToString().Trim() == "")
        {
            msgErr = "Please Select Job Opening From Date !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            txtOpFDate.Focus();
            return msgErr;
        }

        DataTable dt = new DataTable();
        if (HFAutoID.Value == "0") dt = DBData.getDataTable(DBData.DataPath, "Select * From tblJobOpening Where DesignationID = " + Convert.ToInt32(ddlDesignation.SelectedValue) + " and OpFDate=Convert(datetime,'" + txtOpFDate.SelectedDate.ToString() + "',103)");
        else dt = DBData.getDataTable(DBData.DataPath, "Select * From tblJobOpening Where DesignationID = " + Convert.ToInt32(ddlDesignation.SelectedValue) + " And OpFDate=Convert(datetime, '" + txtOpFDate.SelectedDate.ToString().Trim() + "',103) And AutoID <> " + HFAutoID.Value.Trim() + "");
        if (dt.Rows.Count > 0)
        {
            msgErr = "Selected Post Has Already Opening !!";
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
            ddlDesignation.Focus();
        }
        return msgErr;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("JobOpening.aspx");
        }
    }

    private void Submit()
    {
        string reqMsg = ValidateData();
        if (reqMsg.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_JobOpening";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int));
                sqcmd.Parameters["@AutoID"].Value = Convert.ToInt32(HFAutoID.Value);

                sqcmd.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                sqcmd.Parameters["@DesignationID"].Value = Convert.ToInt32(ddlDesignation.SelectedValue);

                sqcmd.Parameters.Add(new SqlParameter("@NoOfVacancy", SqlDbType.Int));
                sqcmd.Parameters["@NoOfVacancy"].Value = txtNoOfVacancy.Value.Trim();

                sqcmd.Parameters.Add(new SqlParameter("@RequiredQualification", SqlDbType.VarChar, 550));
                sqcmd.Parameters["@RequiredQualification"].Value = txtRequiredQualification.Value.Trim();

                sqcmd.Parameters.Add(new SqlParameter("@Experiance", SqlDbType.VarChar, 250));
                sqcmd.Parameters["@Experiance"].Value = txtExperiance.Value.Trim();

                sqcmd.Parameters.Add(new SqlParameter("@OpFDate", SqlDbType.VarChar, 10)).Value = txtOpFDate.SelectedDate.ToString();
                sqcmd.Parameters.Add(new SqlParameter("@OpLDate", SqlDbType.VarChar, 10)).Value = txtOpLDate.SelectedDate.ToString();

                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();

                sqcmd.ExecuteNonQuery();
                Response.Redirect("JobOpening.aspx");
            }
            catch (Exception ex)
            {
                Scriptmassage(ex.Message);
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            Scriptmassage(reqMsg);
            msgDiv.Visible = true;
            lblMsg.Text = reqMsg;
        }
    }

    private void Scriptmassage(string strmsg)
    {
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + strmsg + "');", true);
    }

    private void RefResh()
    {
        ddlDesignation.SelectedIndex = 0; txtExperiance.Value = ""; txtNoOfVacancy.Value = ""; HFAutoID.Value = "0";
        txtRequiredQualification.Value = "";
        btnSave.Text = "Save"; btnDelete.Enabled = false;
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("JobOpening.aspx");
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (HFAutoID.Value != "0")
        {
            DBData.deleteData(DBData.DataPath, "delete from tblJobOpening where AutoID=" + Convert.ToInt32(HFAutoID.Value.Trim()) + "");
            Response.Redirect("JobOpening.aspx");
        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillGridFiltered();
    }
}