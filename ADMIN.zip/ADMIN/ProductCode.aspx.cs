﻿ using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ProductCode : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            Util.BindDropDown(ddlBranch, "BranchName", "AutoID", "Select Branch", DBData.getDataTable(DBData.DataPath, "Select AutoID,BranchName From tblBranchDetail Order By BranchName"));
            Util.BindDropDown(ddlProduct, "ProductName", "AutoID", "Select Product", DBData.getDataTable(DBData.DataPath, "Select AutoID,ProductName From tblProduct Order By ProductName"));
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            //if (Convert.ToInt32(Session["BranchAutoID"]) > 1)
            //{
            //    ddlBranch.SelectedValue = Session["BranchAutoID"].ToString();
            //    ddlBranch.Enabled = false;
            //}
            ddlBranch.SelectedIndex = 1;
        }
        msgDiv.Visible = false;
        lblMsg.Text = "";
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        if (ddlProduct.SelectedIndex > 0)
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "SELECT AutoID,CodeNo,IsNull(OpeningQty,0) as OpeningQty,IsNull(OpeningPc,0) as OpeningPc,IsNull(PRate,0) as PRate,IsNull(SRate,0) as SRate,IsNull(MRate,0) as MRate From tblCode Where ProductAutoID = " + ddlProduct.SelectedValue + " Order By CodeNo");
            gvList.DataSource = dt;
            gvList.DataBind();
        }
    }

    private string ValidateData()
    {
        string reqMsg = "";
        //if (ddlBranch.SelectedIndex<=0)
        //{
        //    reqMsg = "Please Select Branch !!";
        //    ddlBranch.Focus();
        //    return reqMsg;
        //}

        if (ddlProduct.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Product !!";
            ddlProduct.Focus();
            return reqMsg;
        }

        if (txtCode.Value.Trim() == "")
        {
            reqMsg = "Please Enter Code Of Product !!";
            txtCode.Focus();
            return reqMsg;
        }

        if (HFID.Value.Trim() == "0")
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "Select * from tblCode Where BranchAutoID = " + ddlBranch.SelectedValue + " And ProductAutoID = " + ddlProduct.SelectedValue + " And CodeNo = '" + txtCode.Value.Trim() + "'");
            if (dt.Rows.Count > 0)
            {
                reqMsg = "Cannot Create Duplicate Code Of Selected Product !!";
                ddlProduct.Focus();
                return reqMsg;
            }
        }

        if (HFID.Value.Trim() != "0")
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "Select * from tblCode Where BranchAutoID = " + ddlBranch.SelectedValue + " And ProductAutoID = " + ddlProduct.SelectedValue + "  And CodeNo = '" + txtCode.Value.Trim() + "' And AutoID <> " + HFID.Value.Trim() + "");
            if (dt.Rows.Count > 0)
            {
                reqMsg = "Cannot Create Duplicate Code Of Selected Product !!";
                ddlProduct.Focus();
                return reqMsg;
            }
        }

        if (txtQty.Value.Trim() == "")
        {
            txtQty.Value = "0";
        }

        //if (txtPc.Value.Trim() == "")
        //{
        //    txtPc.Value = "0";
        //}
        if (txtPRate.Value.Trim() == "")
        {
            txtPRate.Value = "0";
        }
        if (txtSRate.Value.Trim() == "")
        {
            txtSRate.Value = "0";
        }
        if (txtMRate.Value.Trim() == "")
        {
            txtMRate.Value = "0";
        }
        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_Code";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                if (ddlBranch.SelectedIndex > 0) sqcmd.Parameters.Add(new SqlParameter("@BranchAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlBranch.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@ProductAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlProduct.SelectedValue);
                sqcmd.Parameters.Add(new SqlParameter("@CodeNo", SqlDbType.VarChar)).Value = txtCode.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@OpeningQty", SqlDbType.Int)).Value = Convert.ToInt32(txtQty.Value.Trim());
                sqcmd.Parameters.Add(new SqlParameter("@OpeningPc", SqlDbType.Int)).Value = 0;
                if(txtPRate.Value != "") sqcmd.Parameters.Add(new SqlParameter("@PRate", SqlDbType.Float)).Value = Convert.ToDouble(txtPRate.Value.Trim());
                if (txtSRate.Value != "") sqcmd.Parameters.Add(new SqlParameter("@SRate", SqlDbType.Float)).Value = Convert.ToDouble(txtSRate.Value.Trim());
                if (txtMRate.Value != "") sqcmd.Parameters.Add(new SqlParameter("@MRate", SqlDbType.Float)).Value = Convert.ToDouble(txtMRate.Value.Trim());
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();
                sqcmd.ExecuteNonQuery();
                Response.Redirect("ProductCode.aspx");
                //Refresh();
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("ProductCode.aspx");
        }
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[7].Text).ToString();
        txtCode.Value = gvList.SelectedRow.Cells[1].Text;
        txtQty.Value = gvList.SelectedRow.Cells[2].Text;
        //txtPc.Value = gvList.SelectedRow.Cells[3].Text;

        txtPRate.Value = gvList.SelectedRow.Cells[4].Text;
        txtSRate.Value = gvList.SelectedRow.Cells[5].Text;
        txtMRate.Value = gvList.SelectedRow.Cells[6].Text;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlBranch.SelectedIndex > 0) FillGrid();
    }

    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProduct.SelectedIndex > 0) FillGrid();
    }

    private void Refresh()
    {
        Response.Redirect("ProductCode.aspx");
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Refresh();
    }
}
