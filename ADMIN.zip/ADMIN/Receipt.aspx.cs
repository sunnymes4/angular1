﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ADMIN_Receipt : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    SqlConnection sqcon = null;
    SqlTransaction tran = null;
    SqlCommand sqcmd = null;
    string appID = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            Util.BindDropDown(ddlBranch, "BranchName", "AutoID", "Branch", DBData.getDataTable(DBData.DataPath, "Select AutoID,BranchName From tblBranchDetail Order By AutoID"));
            Util.BindDropDown(ddlReceiptType, "RecieptType", "AutoID", "Receipt-Type", DBData.getDataTable(DBData.DataPath, "Select AutoID,RecieptType From tblReceiptType"));
            msgDiv.Visible = false;
            divRegDetails.Visible = false;
            divCheckUser.Visible = false;
            divUserDetails.Visible = false;
        }
    }

    private string ValidateSearch()
    {
        string reqMsg = "";
        if (ddlBranch.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Branch Name";
            ddlBranch.Focus();
            return reqMsg;
        }

        if (txtRegNo.Value.Trim() == "")
        {
            reqMsg = "Please Enter Registration No .";
            txtRegNo.Focus();
            return reqMsg;
        }
        return reqMsg;
    }

    private void SearchRegDetails()
    {
        try
        {
            string msgErr = ValidateSearch();
            if (msgErr.Equals(""))
            {
                divRegDetails.Visible = true;
                RegistrationDetails(txtRegNo.Value.Trim());
                msgDiv.Visible = false;
            }
            else
            {
                msgDiv.Visible = true;
                lblMsg.Text = msgErr;
            }
        }
        catch (Exception ex) 
        {
            DetailsView1.DataSource = null;
            DetailsView1.DataBind();
            divRegDetails.Visible = false;
            //====================================
            msgDiv.Visible = true;
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        SearchRegDetails();
        divCheckUser.Visible = false;
        divUserDetails.Visible = false;
    }

    private void RegistrationDetails(string RegNo)
    {
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "[dbo].[SP_S_UserRegistration] 0,'" + RegNo + "'");
        if (dt.Rows.Count > 0)
        {
            //DOSMS(dt.Rows[0]["MobileNo"].ToString(), dt.Rows[0]["Name"].ToString(), dt.Rows[0]["ApplicationID"].ToString());
            msgDiv.Visible = true;
            //LblMsg.Text = "Your Registration Has Been Completed. Your Registration No :- " + dt.Rows[0]["ApplicationID"].ToString() + "";
            //LblMsg.ForeColor = System.Drawing.Color.Green;
            DetailsView1.DataSource = null;
            DetailsView1.DataSource = dt;
            DetailsView1.DataBind();
            hfRegID.Value = dt.Rows[0]["AutoID"].ToString();
            hfUserName.Value = dt.Rows[0]["Name"].ToString();
            hfEmailID.Value = dt.Rows[0]["EmailID"].ToString();
            btnSave.Enabled = true;
            //================================================
            DataTable dt1 = new DataTable();
            dt1 = DBData.getDataTable(DBData.DataPath, "Select * From tblReceiptPaymentDetail Where RAutoID = " + hfRegID.Value.Trim() + "");
            if (dt1.Rows.Count > 0) Util.BindDropDown(ddlReceiptType, "RecieptType", "AutoID", "Receipt-Type", DBData.getDataTable(DBData.DataPath, "Select AutoID,RecieptType From tblReceiptType where AutoID <> 1"));
            else Util.BindDropDown(ddlReceiptType, "RecieptType", "AutoID", "Receipt-Type", DBData.getDataTable(DBData.DataPath, "Select AutoID,RecieptType From tblReceiptType where AutoID In(1)"));
            //================================================
            FillGrid();
        }
        else
        {
            hfRegID.Value = "0"; hfUserName.Value = ""; hfEmailID.Value = "";
            DetailsView1.DataSource = null;
            DetailsView1.DataBind();
            divRegDetails.Visible = false;
            msgDiv.Visible = true;
            lblMsg.Text = "Data Not Found ...";
        }
    }

    ////private void CheckReceiptTypeInReceiptPayment()
    ////{
    ////    DataTable dt = new DataTable();
    ////    dt = DBData.getDataTable(DBData.DataPath, " selecct ReceiptTypeAutoID from tblReceiptPaymentDetail Where RAutoID=" + Convert.ToInt32(hfRegID.Value) + "");
    ////    if (dt.Rows.Count > 0)
    ////    {

    ////    }
    ////}

    protected void ddlReceiptType_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlReceiptType.SelectedIndex > 0)
        {
            if (ddlReceiptType.SelectedValue == "1")
            {
                divRegDetails.Visible = true;
                divCheckUser.Visible = true;
            }
            else
            {
                divUserDetails.Visible = false;
            }
        }
    }

    private string Validate()
    {
        string reqMsg = "";
        if (ddlBranch.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Branch !!";
            ddlBranch.Focus();
            return reqMsg;
        }

        if (btnSave.Text == "Submit")
        {
            if (ddlReceiptType.SelectedIndex <= 0)
            {
                reqMsg = "Please Select Receipt Type";
                ddlReceiptType.Focus();
                return reqMsg;
            }
        }

        if (txtAmount.Value.Trim() == "")
        {
            reqMsg = "Please Enter Receipt Amount.";
            txtAmount.Focus();
            return reqMsg;
        }

        if (ddlReceiptType.SelectedValue == "1")
        {

            if (txtUserID.Value.Trim() != "")
            {
                if (txtPassword.Value.Trim() == "")
                {
                    reqMsg = "Please Enter Password.";
                    txtPassword.Focus();
                    return reqMsg;
                }

                if (txtConfirmPassword.Value.Trim() == "")
                {
                    reqMsg = "Please Enter Confirm Password.";
                    txtConfirmPassword.Focus();
                    return reqMsg;
                }

                if (txtPassword.Value.Trim() != txtConfirmPassword.Value.Trim())
                {
                    reqMsg = "Password And Confirm Password Should Be Same. Please Re-Enter It..";
                    txtConfirmPassword.Focus();
                    return reqMsg;
                }
            }
        }

        if (txtUserID.Value.Trim() != "")
        {
            int str = Convert.ToInt32(DBData.GetScalar(DBData.DataPath, "Select IsNull(Count(*),0) From tblUserDetail Where UserName = '" + txtUserID.Value.Trim() + "'"));
            if (str > 0)
            {
                reqMsg = "User Name Already Exist ! Please Try Again .";
                txtUserID.Focus();
                return reqMsg;
            }
        }
        return reqMsg;
    }


    protected void btnSave_Click(object sender, EventArgs e)
    {
        Submit();
    }

    private void Submit()
    {
        try
        {
            string msgErr = Validate();
            if (msgErr.Equals(""))
            {
                sqcon = new SqlConnection(DBData.DataPath);
                if (sqcon.State == ConnectionState.Closed) sqcon.Open();
                tran = sqcon.BeginTransaction(System.Data.IsolationLevel.Serializable);
                IU_ReceiptPaymentDetail();
                if (ddlReceiptType.SelectedValue == "1") IU_UserDetails();
                tran.Commit();
                ddlReceiptType.SelectedIndex = 0;
                txtAmount.Value = "";
                txtRemarks.Value = "";
                txtUserID.Value = "";
                txtPassword.Value = "";
                txtConfirmPassword.Value = "";
                Response.Redirect("ReceiptSuccess.aspx?RF=" + hfRefNo.Value.ToString() + "", false);
            }
            else
            {
                lblMsg.ForeColor = System.Drawing.Color.Red;
                msgDiv.Visible = true;
                lblMsg.Text = msgErr;
            }
        }
        catch (Exception ex)
        {
            tran.Rollback();
            msgDiv.Visible = true;
            lblMsg.Text = ex.Message;
        }
        //finally
        //{
        //    sqcon.Close();
        //}
    }

    private void IU_ReceiptPaymentDetail()
    {
        sqcmd = new SqlCommand("SP_IU_ReceiptPaymentDetail", sqcon);
        sqcmd.CommandType = CommandType.StoredProcedure;                                                     
        sqcmd.Transaction = tran;
        sqcmd.Parameters.AddWithValue("@AutoID", hfReceiptID.Value);
        sqcmd.Parameters.AddWithValue("@Type", "Receipt");
        sqcmd.Parameters.AddWithValue("@RAutoID", hfRegID.Value);
        if (btnSave.Text == "Submit")
        {
            if (ddlReceiptType.SelectedIndex > 0) sqcmd.Parameters.AddWithValue("@ReceiptTypeAutoID", ddlReceiptType.SelectedValue);
        }
        else
        {
            sqcmd.Parameters.AddWithValue("@ReceiptTypeAutoID", hfReceiptTypeID.Value);
        }
        sqcmd.Parameters.AddWithValue("@Amount", txtAmount.Value.Trim());
        sqcmd.Parameters.AddWithValue("@Remarks", txtRemarks.Value.Trim());
        sqcmd.Parameters.AddWithValue("@CreatedBy", Page.User.Identity.Name.ToString());
        sqcmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now.ToString("dd/MM/yyyy"));
         sqcmd.Parameters.AddWithValue("@CreatedIP", Request.UserHostAddress.ToString());
         sqcmd.Parameters.AddWithValue("@BranchID", ddlBranch.SelectedValue.ToString());
          DataTable dt = new DataTable();
        dt = DBData.SqlDataAdapter(sqcmd);
        if (hfRefNo.Value.Trim() == "") hfRefNo.Value = dt.Rows[0][0].ToString();
        sqcmd.Cancel();
    }

    private void IU_UserDetails()
    {
        sqcmd = new SqlCommand("SP_IU_UserDetail", sqcon);
        sqcmd.CommandType = CommandType.StoredProcedure;
        sqcmd.Transaction = tran;
        sqcmd.Parameters.AddWithValue("@AutoID", 0);
        sqcmd.Parameters.AddWithValue("@UserName", txtUserID.Value);
        sqcmd.Parameters.Add("@Password", SqlDbType.VarChar, 50).Value = new Encryptor("x7hkVXoObeI=").Encrypt(txtConfirmPassword.Value.Trim()).ToString();
        sqcmd.Parameters.AddWithValue("@CreatedBy", Page.User.Identity.Name);
        sqcmd.Parameters.AddWithValue("@NameOfUser", hfUserName.Value);
        sqcmd.Parameters.AddWithValue("@ApplicationAutoID", null);
        sqcmd.Parameters.AddWithValue("@EmailID", hfEmailID.Value);
        sqcmd.Parameters.AddWithValue("@RoleAutoID", 3);
        sqcmd.Parameters.AddWithValue("@LoginAutoID", 1);//Convert.ToInt32(Session["LoginAutoID"])
        sqcmd.Parameters.AddWithValue("@IPAddress", Request.UserHostAddress.ToString());
        sqcmd.Parameters.AddWithValue("@IsAlive", "True");
        sqcmd.ExecuteNonQuery();
        sqcmd.Cancel();
    }

    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtAmount.Value = gvList.SelectedRow.Cells[5].Text;
            hfReceiptID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[6].Text).ToString();
            txtRemarks.Value = gvList.SelectedRow.Cells[7].Text;
            hfReceiptTypeID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[8].Text).ToString();
            ddlBranch.SelectedValue = Convert.ToInt32(gvList.SelectedRow.Cells[9].Text).ToString();
            ddlBranch.Enabled=false;
            btnDelete.Enabled = true;
            btnSave.Text = "Update";
        }
        catch (Exception ex) { }
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }

    private void FillGrid()
    {
        Util.BindGridView(gvList, "Select ROW_NUMBER() Over (Order By RefNo) as SNo,AutoID,RefNo, CONVERT(varchar(10),CreatedDate,103) as Date,ReceiptTypeAutoID,(Select RecieptType From tblReceiptType Where AutoID = ReceiptTypeAutoID) As RecieptType,Amount,Remarks,BranchID,(Select BranchName From tblBranchDetail Where AutoID = BranchID) As Branch From tblReceiptPaymentDetail Where Type='Receipt' And RAutoID=" + Convert.ToInt32(hfRegID.Value) + "");
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if (hfReceiptID.Value != "0")
        {
            DBData.deleteData(DBData.DataPath, "delete from tblReceiptPaymentDetail where AutoID=" + Convert.ToInt32(hfReceiptID.Value.Trim()) + "");
            Response.Redirect("Receipt.aspx");
        }
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Receipt.aspx");
    }

    protected void chkUser_CheckedChanged(object sender, EventArgs e)
    {
        if (chkUser.Checked == true) divUserDetails.Visible = true;
        else
        {
            txtUserID.Value = "";
            txtPassword.Value = "";
            txtConfirmPassword.Value = "";
            divUserDetails.Visible = false;
        }
    }
}
