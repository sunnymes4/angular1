﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class ADMIN_FilterBioData : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Util.BindDropDown(ddlDesignation, "Designation", "AutoID", "All", DBData.getDataTable(DBData.DataPath, "Select AutoID,Designation From tblDesignation Order By AutoID"));
        }
        msgDiv.Visible = false;
        lblMsg.Text = "";
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        FillGrid();
    }

    private void FillGrid()
    {
        //if (ddlDesignation.SelectedIndex > 0)
        //{
            gvList.DataSource = null;
            gvList.DataBind();
            DataTable dt = new DataTable();
            if (ddlDesignation.SelectedIndex == 0) dt = DBData.getDataTable(DBData.DataPath, "Select Row_Number() Over (Order By A.DesignationID) SN,A.AutoID,(Select Designation From tblDesignation Where AutoID = A.DesignationID) ApplyFor,EntryDate As ApplyDate,Name,LAddress As Address,EQualification As Qualification,Experiance  As 'Exp', MobileNo,BioData from tblApplyForJob A Where A.CStatus = 'N' Order By A.DesignationID");
            else dt = DBData.getDataTable(DBData.DataPath, "Select Row_Number() Over (Order By EntryDate) SN,A.AutoID,(Select Designation From tblDesignation Where AutoID = A.DesignationID) ApplyFor,EntryDate As ApplyDate,Name,LAddress As Address,EQualification As Qualification,Experiance  As 'Exp', MobileNo,BioData from tblApplyForJob A Where A.DesignationID = " + ddlDesignation.SelectedValue + " And A.CStatus = 'N'");
            gvList.DataSource = dt;
            gvList.DataBind();
        //}
        //else
        //{
        //    msgDiv.Visible = true;
        //    lblMsg.Text = "Please Select Post For Filter Bio-Data !!";
        //}
    }

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }
}
