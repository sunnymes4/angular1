﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ADMIN_Unit : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _id = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        lblMsg.Text = "";
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private void FillGrid()
    {
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "SELECT Row_Number() Over (Order By U.AutoID) as SN,U.* From tblUnit U");
        gvList.DataSource = dt;
        gvList.DataBind();
    }

    private string ValidateData()
    {
        string reqMsg = "";
        if (txtUnit.Value == "")
        {
            reqMsg = "Please Enter Unit Name .!!";
            txtUnit.Focus();
            return reqMsg;
        }

        return reqMsg;
    }

    private void Submit()
    {
        string msgErr = "";
        msgErr = ValidateData();
        if (msgErr.Equals(""))
        {
            SqlConnection sqcon = new SqlConnection(DBData.DataPath);
            SqlCommand sqcmd = new SqlCommand();
            sqcmd.Connection = sqcon;
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.CommandText = "SP_IU_Unit";
            try
            {
                sqcon.Open();
                sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
                sqcmd.Parameters.Add(new SqlParameter("@Unit", SqlDbType.VarChar, 500)).Value = txtUnit.Value.Trim();
                sqcmd.Parameters.Add(new SqlParameter("@LoginAutoID", SqlDbType.Int)).Value = Session["LoginAutoID"];
                sqcmd.Parameters.Add(new SqlParameter("@IPAddress", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();
                sqcmd.ExecuteNonQuery();
                Response.Redirect("Unit.aspx");
                //Refresh();
            }
            catch (Exception ex)
            {
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                sqcon.Close();
                sqcon.Dispose();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void Refresh()
    {
        btnSave.Text = "Save";
        btnDelete.Enabled = false;
        FillGrid();
        txtUnit.Value = "";
        HFID.Value = "0";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Page.IsValid && Session["RefrechCheck"].ToString() == ViewState["RefrechCheck"].ToString())
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            Submit();
        }
        else
        {
            Response.Redirect("Unit.aspx");
        }
    }

    private string ValidateForDelete()
    {
        string reqMsg = "";
        DataTable dt = new DataTable();
        dt = DBData.getDataTable(DBData.DataPath, "Select * From tblProduct Where UnitAutoID = " + HFID.Value.Trim() + "");
        if (dt.Rows.Count > 0) return reqMsg = "This Unit is Already Used On Product So You Cannot Delete This!!";
        else return reqMsg;
        return "";
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string msgErr = "";
        msgErr = ValidateForDelete();
        if (msgErr.Equals(""))
        {
            DBData.deleteData(DBData.DataPath, "Delete From tblUnit Where AutoID = " + HFID.Value.Trim() + "");
            Response.Redirect("Unit.aspx");
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }
    protected void btnRefresh_Click1(object sender, EventArgs e)
    {
        Refresh();
    }
    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        FillGrid();
    }
    protected void gvList_SelectedIndexChanged(object sender, EventArgs e)
    {
        btnSave.Text = "Update";
        HFID.Value = Convert.ToInt32(gvList.SelectedRow.Cells[3].Text).ToString();
        txtUnit.Value = gvList.SelectedRow.Cells[2].Text;
        btnDelete.Enabled = true;
        btnSave.Enabled = true;
    }
}
