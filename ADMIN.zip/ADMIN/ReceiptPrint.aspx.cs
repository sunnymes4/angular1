﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ADMIN_ReceiptPrint : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            //Convert.ToString(Request.QueryString["RF"].ToString())
            string str = Convert.ToString(Request.QueryString["RF"].ToString());
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "Select ROW_NUMBER() Over (Order By RPD.RefNo) as SNo,RPD.AutoID,RPD.RefNo, CONVERT(varchar(10),RPD.CreatedDate,103) as Date,RPD.ReceiptTypeAutoID,RT.RecieptType,RPD.Amount,RPD.Remarks,UR.* From tblReceiptPaymentDetail RPD Inner Join tblReceiptType RT on RT.AutoID=RPD.ReceiptTypeAutoID Inner join tblUserRegistration UR on UR.AutoID=RPD.RAutoID where RPD.Type='Receipt' and RPD.RefNo='" + str + "'");
            if (dt.Rows.Count > 0)
            {
                lblReceiptNo.Text = dt.Rows[0]["RefNo"].ToString();
                lblDate.Text = dt.Rows[0]["Date"].ToString();
                lblAddress.Text = dt.Rows[0]["TAddress"].ToString();
                lblAmount.Text = dt.Rows[0]["Amount"].ToString();
                lblContactNo.Text = dt.Rows[0]["MobileNo"].ToString();
                lblIDNo.Text = dt.Rows[0]["ApplicationID"].ToString();
                lblName.Text = dt.Rows[0]["Name"].ToString();
                lblReceiptType.Text = dt.Rows[0]["RecieptType"].ToString();
                //lblTransferID.Text = dt.Rows[0]["Date"].ToString();
            }
            else
            {
                lblAddress.Text = ""; lblAmount.Text = "0.00"; lblContactNo.Text = ""; lblDate.Text = ""; lblIDNo.Text = "";
                lblName.Text = ""; lblReceiptNo.Text = ""; lblReceiptType.Text = ""; lblTransferID.Text = "";
            }
        }
    }
}
