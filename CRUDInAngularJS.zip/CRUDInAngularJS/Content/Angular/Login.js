﻿app.controller("myLoginCntrl", function ($scope, myService) {
    //Login
    $scope.ErrorClass = 'hide';
    $scope.FormClass = 'show';
    $scope.LoginCheck = function () {
        $scope.ErrorClass = 'hide';
        var User = {
            UserName: $scope.uName,
            Password: $scope.password
        };
        //$("#divLoading").show();
        var getData = myService.UserLogin(User);
       
        getData.then(function (msg)
        {
            if (msg.data == "0")
            {
                //$("#divLoading").hide();
                $scope.ErrorClass = 'show';
                $scope.FormClass = 'hide';
                $scope.uName = '';
                $scope.password = '';
                $scope.msg = "Wrong Username And Password Entered ! Please Try Again !";
            }
            else if (msg.data == "-1") {
                //$("#divLoading").hide();
                $scope.ErrorClass = 'show';
                $scope.FormClass = 'hide';
                $scope.msg = "Please Enter Username And Password !";
            }
            else
            {
                uID = msg.data;
                //$("#divLoading").hide();
                window.location.href = "/Home/Index";
            }
        });
    }

    $scope.clearFields = function ()
    {
        debugger;
        $scope.uName = '';
        $scope.password = '';
        $scope.$broadcast("uName");
    }

    $scope.alertmsg = function () {
        $scope.ErrorClass = 'hide';
        $scope.FormClass = 'show';
    }

});

