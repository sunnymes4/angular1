﻿app.controller("myDashboardCntrl", function ($scope, myService)
{
    GetUserInfo();
    //To Get All Records 
    function GetUserInfo() {
        debugger;
        var getData = myService.getUserInfo();
        debugger;
        getData.then(function (user) {
            $scope.userInfo = user.data;
        }, function () {
            alert('Error in getting User Info !!');
        });
    }
});