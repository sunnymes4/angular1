﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ADMIN_Sale : System.Web.UI.Page
{
    DataTable dt = new DataTable();
    DataColumn dc = new DataColumn();
    SqlTransaction tran = null;
    SqlCommand sqcmd = null;
    int _saleAutoID = 0;
    UtilityCls Util = new UtilityCls();
    SqlConnection sqcon = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            Util.BindDropDown(ddlParty, "Name", "AutoID", "Select Party", DBData.getDataTable(DBData.DataPath, "Select AutoID,(Name + ' - ' + EmployeeID) As Name From tblEmployeeJoining where Status='True'"));
            Util.BindDropDown(ddlProduct, "ProductName", "AutoID", "Select Product", DBData.getDataTable(DBData.DataPath, "Select AutoID,ProductName From tblProduct Order By AutoID"));
            //txtDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
        }
        msgDiv.Visible = false;
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    protected void ddlParty_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlParty.SelectedIndex > 0)
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "Select * From tblEmployeeJoining Where AutoID = " + ddlParty.SelectedValue + "");
            if (dt.Rows.Count > 0)
            {
                txtAddress.Value = dt.Rows[0]["PAddress"].ToString();
                txtContactNo.Value = dt.Rows[0]["MobileNo"].ToString();
            }
            else
            {
                txtAddress.Value = ""; txtContactNo.Value = "";
            }
        }
        else
        {
            txtAddress.Value = ""; txtContactNo.Value = "";
        }
    }
    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProduct.SelectedIndex > 0)
        {
            Util.BindDropDown(ddlCode, "CodeNo", "AutoID", "Select Code", DBData.getDataTable(DBData.DataPath, "Select AutoID,CodeNo From tblCode Where ProductAutoID = " + ddlProduct.SelectedValue + " Order By AutoID"));
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "select ISNULL(T.Percentage,0) as TaxPercent from tblProduct P Inner Join tblTax T on T.AutoID=P.TaxAutoID where P.AutoID=" + Convert.ToInt32(ddlProduct.SelectedValue) + "");
            if (dt.Rows.Count > 0)
            {
                hfTaxPercent.Value = dt.Rows[0]["TaxPercent"].ToString();
            }
            else
            {
                hfTaxPercent.Value = "0";
            }
        }
    }
    protected void ddlCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCode.SelectedIndex > 0)
        {
            DataTable dt = new DataTable();
            dt = DBData.getDataTable(DBData.DataPath, "SELECT AutoID,CodeNo,IsNull(OpeningQty,0) as OpeningQty,IsNull(OpeningPc,0) as OpeningPc,IsNull(PRate,0) as PRate,IsNull(SRate,0) as SRate,IsNull(MRate,0) as MRate From tblCode Where ProductAutoID=" + ddlProduct.SelectedValue + " And AutoID = " + ddlCode.SelectedValue + "");
            if (dt.Rows.Count > 0)
            {
                txtSRate.Value = dt.Rows[0]["SRate"].ToString();
                txtTax.Value = "0";

            }
        }
    }

    private string ValidateSale()
    {
        string reqMsg = "";
        if (ddlParty.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Party/Employee Name !!";
            ddlParty.Focus();
            return reqMsg;
        }
        if (gvList.Rows.Count <= 0)
        {
            reqMsg = "Please Add Atlease One Product For Sale. !!";
            ddlProduct.Focus();
            return reqMsg;
        }
        return reqMsg;
    }

    private string ValidateSaleDetails()
    {
        string reqMsg = "";
        if (ddlProduct.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Product Name !!";
            ddlProduct.Focus();
            return reqMsg;
        }

        if (ddlCode.SelectedIndex <= 0)
        {
            reqMsg = "Please Select Product Code !!";
            ddlCode.Focus();
            return reqMsg;
        }

        if (txtSRate.Value.Trim() == "")
        {
            reqMsg = "Please Enter Product Sale Rate !!";
            txtSRate.Focus();
            return reqMsg;
        }

        if (txtQty.Value.Trim() == "")
        {
            reqMsg = "Please Enter Product Sale Quantity !!";
            txtQty.Focus();
            return reqMsg;
        }

        if (txtTax.Value.Trim() == "")
        {
            reqMsg = "Please Enter Product Sale Tax Amount !!";
            txtTax.Focus();
            return reqMsg;
        }

        if (txtAmount.Value.Trim() == "")
        {
            reqMsg = "Please Enter Product Sale Total Amount !!";
            txtAmount.Focus();
            return reqMsg;
        }
        return reqMsg;
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string msgErr = "";
        msgErr = ValidateSaleDetails();
        if (msgErr.Equals(""))
        {
            if (ViewState["dt"] != null)
            {
                dt = (DataTable)ViewState["dt"];
            }

            if (dt.Columns.Count == 0)
            {
                dt.Columns.Add("SN", typeof(string));
                dt.Columns.Add("PID", typeof(string));
                dt.Columns.Add("ProductName", typeof(string));
                dt.Columns.Add("BID", typeof(string));
                dt.Columns.Add("Code", typeof(string));
                dt.Columns.Add("SRate", typeof(string));
                dt.Columns.Add("Vat", typeof(string));
                dt.Columns.Add("Qty", typeof(string));
                dt.Columns.Add("Amount", typeof(string));
            }

            DataRow NewRow = dt.NewRow();
            NewRow[0] = dt.Rows.Count + 1;
            NewRow[1] = ddlProduct.SelectedValue.ToString();
            NewRow[2] = ddlProduct.SelectedItem.Text.Trim();
            NewRow[3] = ddlCode.SelectedValue.ToString();
            NewRow[4] = ddlCode.SelectedItem.Text.Trim();
            NewRow[5] = txtSRate.Value.Trim();
            NewRow[6] = txtTax.Value.Trim();
            NewRow[7] = txtQty.Value.Trim();
            NewRow[8] = txtAmount.Value.Trim();
            dt.Rows.Add(NewRow);
            ViewState["dt"] = dt;
            gvList.DataSource = dt;
            gvList.DataBind();
            //======================================
            ClearProductDetails();
            GetFooterSaleDetails();
            //======================================
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void GetFooterSaleDetails()
    {
        try
        {
            int TQty = 0; double TAmount = 0;
            if (gvList.Rows.Count > 0) txtTotalItem.Value = gvList.Rows.Count.ToString();
            else txtTotalItem.Value = "0";
            txtTQty.Value = "0"; txtTotalAmount.Value = "0";
            for (int i = 0; i <= gvList.Rows.Count - 1; i++)
            {
                TQty += Convert.ToInt32(gvList.Rows[i].Cells[8].Text.ToString());
                txtTQty.Value = TQty.ToString();
                TAmount += Convert.ToDouble(gvList.Rows[i].Cells[9].Text.ToString());
                txtTotalAmount.Value = TAmount.ToString();
            }
        }
        catch (Exception ex) { }
    }

    protected void gvList_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //try
        //{
        //    if (ViewState["dt"] != null)
        //    {
        //        dt = (DataTable)ViewState["dt"];
        //        for (int i = 0; i <= dt.Rows.Count; i++)
        //        {
        //            if (dt.Rows[i]["SN"].ToString() == gvList.Rows[e.RowIndex].Cells[0].Text.ToString())
        //            {
        //                dt.Rows.RemoveAt(i);
        //                i = dt.Rows.Count;
        //            }
        //        }
        //        for (int i = 0; i < dt.Rows.Count; i++) dt.Rows[i]["ID"] = (++i).ToString();
        //        ViewState["dt"] = dt;

        //        gvList.DataSource = dt;
        //        gvList.DataBind();
        //    }
        //}
        //catch (Exception ex) { }
    }

    private void ClearProductDetails()
    {
        ddlProduct.SelectedIndex = 0; ddlCode.SelectedIndex = 0; txtSRate.Value = ""; txtQty.Value = "";
        txtTax.Value = ""; txtAmount.Value = "";
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string msgErr = "";
        msgErr = ValidateSale();
        if (msgErr.Equals(""))
        {
            try
            {
                sqcon = new SqlConnection(DBData.DataPath);
                if (sqcon.State == ConnectionState.Closed) sqcon.Open();
                tran = sqcon.BeginTransaction(System.Data.IsolationLevel.Serializable);
                IU_Sale();
                IU_Sale_Details();
                tran.Commit();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                msgDiv.Visible = true;
                lblMsg.Text = ex.Message;
            }
            finally
            {
                Util.CON.Close();
            }
        }
        else
        {
            msgDiv.Visible = true;
            lblMsg.Text = msgErr;
        }
    }

    private void IU_Sale()
    {
        sqcmd = new SqlCommand("SP_IU_Sale", sqcon);
        sqcmd.CommandType = CommandType.StoredProcedure;
        sqcmd.Transaction = tran;
        sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
        sqcmd.Parameters.Add(new SqlParameter("@RefDate", SqlDbType.VarChar, 50)).Value = System.DateTime.Now.ToString("dd/MM/yyyy");
        if (ddlParty.SelectedIndex > 0) sqcmd.Parameters.Add(new SqlParameter("@PartyLedgerAutoID", SqlDbType.Int)).Value = Convert.ToInt32(ddlParty.SelectedValue);
        if (txtTotalItem.Value != "") sqcmd.Parameters.Add(new SqlParameter("@TItems", SqlDbType.Int)).Value = Convert.ToInt32(txtTotalItem.Value);
        if (txtTQty.Value != "") sqcmd.Parameters.Add(new SqlParameter("@TQty", SqlDbType.Int)).Value = Convert.ToInt32(txtTQty.Value);
        if (txtTotalAmount.Value != "") sqcmd.Parameters.Add(new SqlParameter("@GrandTotal", SqlDbType.Float)).Value = Convert.ToDouble(txtTotalAmount.Value.Trim());
        //sqcmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.VarChar, 50)).Value = Session["LoginAutoID"].ToString();
        sqcmd.Parameters.Add(new SqlParameter("@CreatedIP", SqlDbType.VarChar, 50)).Value = Request.UserHostAddress.ToString();
        DataTable dt = DBData.SqlDataAdapter(sqcmd);
        hfSaleID.Value = dt.Rows[0][0].ToString();
        hfSaleRefNo.Value = dt.Rows[0][1].ToString();
        sqcmd.ExecuteNonQuery();
        sqcmd.Cancel();
    }

    private void IU_Sale_Details()
    {
        for (int i = 0; i <= gvList.Rows.Count - 1; i++)
        {
            sqcmd = new SqlCommand("SP_I_SaleDetail", sqcon);
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.Transaction = tran;
            sqcmd.Parameters.Add(new SqlParameter("@AutoID", SqlDbType.Int)).Value = Convert.ToInt32(HFID.Value);
            sqcmd.Parameters.Add(new SqlParameter("@SaleAutoID", SqlDbType.Int)).Value = Convert.ToInt32(hfSaleID.Value.Trim());
            sqcmd.Parameters.Add(new SqlParameter("@SN", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[1].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@ProductAutoID", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[2].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@CodeAutoID", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[4].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@SRate", SqlDbType.Float)).Value = Convert.ToDouble(gvList.Rows[i].Cells[6].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@TaxAmount", SqlDbType.Float)).Value = Convert.ToDouble(gvList.Rows[i].Cells[7].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@SaleQty", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[8].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@Amount", SqlDbType.Float)).Value = Convert.ToDouble(gvList.Rows[i].Cells[9].Text.ToString());
            sqcmd.ExecuteNonQuery();
            sqcmd.Cancel();

            //==========================================================================
            //=Stock InQty/OutQty Entry
            sqcmd = new SqlCommand("SP_I_StockInOutDetail", sqcon);
            sqcmd.CommandType = CommandType.StoredProcedure;
            sqcmd.Transaction = tran;
            sqcmd.Parameters.Add(new SqlParameter("@FormAutoID", SqlDbType.Int)).Value = 2;
            sqcmd.Parameters.Add(new SqlParameter("@BillAutoID", SqlDbType.Int)).Value = Convert.ToInt32(hfSaleID.Value.Trim());
            sqcmd.Parameters.Add(new SqlParameter("@ProductAutoID", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[2].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@BatchAutoID", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[4].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@OutQty", SqlDbType.Int)).Value = Convert.ToInt32(gvList.Rows[i].Cells[8].Text.ToString());
            sqcmd.Parameters.Add(new SqlParameter("@BillNo", SqlDbType.VarChar, 50)).Value = hfSaleRefNo.Value.Trim().ToString();
            sqcmd.Parameters.Add(new SqlParameter("@BillDate", SqlDbType.VarChar, 50)).Value = System.DateTime.Now.ToString("dd/MM/yyyy");
            sqcmd.ExecuteNonQuery();
            sqcmd.Cancel();
        }
    }

    private void U_BillSeries()
    {
        
    }
}
