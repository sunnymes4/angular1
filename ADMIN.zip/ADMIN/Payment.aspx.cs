﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;

public partial class ADMIN_Payment : System.Web.UI.Page
{
    UtilityCls Util = new UtilityCls();
    private int _CCode = 0;
    private string appID = string.Empty;
    SqlTransaction tran = null;
    SqlCommand sqcmd = null;
    SqlConnection sqcon = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["RefrechCheck"] = DateTime.Now.ToString();
            ViewState["RefrechCheck"] = Session["RefrechCheck"];
            FillGrid();
        }
        msgDiv.Visible = false;
        lblMsg.Text = "";
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["RefrechCheck"] = Session["RefrechCheck"];
    }

    private string ValidateForSearch()
    {
        string reqErr = "";
        //if (ddlAC.SelectedIndex <= 0)
        //{
        //    reqErr = "कृपया विधान सभा चुने !!";
        //    ddlAC.Focus();
        //    return reqErr;
        //}

        return reqErr;
    }

    private void FillGrid()
    {
        Util.BindGridView(gvList, "select Row_Number() Over (Order By UR.AutoID) as SN,UR.*,D.District,(FirstName + ' ' + LastName) as Name,(select isnull(Amount,0) from tblFeeType Where AutoID=1) as RegFee from dbo.tblUserRegistration UR Left Outer Join tblDistrict D on D.AutoID=UR.DistrictAutoID where IsPaid='False'");
    }

    protected void LbtnDoPay_Click(object sender, EventArgs e)
    {
        LinkButton lnkbtn = sender as LinkButton;
        GridViewRow gvrow = lnkbtn.NamingContainer as GridViewRow;
        hfAutoID.Value = gvList.DataKeys[gvrow.RowIndex].Value.ToString();
        if (hfAutoID.Value != "0" || hfAutoID.Value != "")
        {
            DBData.UpDateData(DBData.DataPath, "Update tblUserRegistration SET IsPaid='True', Amount=(select isnull(Amount,0) from tblFeeType Where AutoID=1),PayDate=Convert(datetime,'" + System.DateTime.Now.ToString("dd/MM/yyyy") + "',103),ReceivedBy=" + Convert.ToInt32(Session["LoginAutoID"]) + " where AutoID=" + Convert.ToInt32(hfAutoID.Value) + "");
            FillGrid();
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Acknowledgement-No " + AcNo + " Online Booking Approved successfully')", true);
            //FillGridFilter();
            //Response.Redirect("GMApplicationDetails.aspx?GMCC=" + hfCCode.Value + "");
            //RejectApplication();
        }
    }
}
